
public class internet {

}
